from turtle import Screen
from paddle import Paddle
from boll import Boll
from scoreboard import Scoreboard_2
import time
from scoreboard import Scoreboard
scoreboard = Scoreboard()
scoreboard_2 = Scoreboard_2()

screen = Screen()
screen.tracer(0)
screen.setup(width= 800, height=600)
screen.bgcolor("black")

r_paddle = Paddle((375,0))
l_paddle = Paddle((-375,0))
boll = Boll()

screen.listen()
screen.onkey(r_paddle.up,"Up")
screen.onkey(r_paddle.down,"Down")

screen.onkey(l_paddle.up,"w")
screen.onkey(l_paddle.down,"s")
is_game_on = True
while is_game_on:
    time.sleep(boll.move_speed)
    screen.update()
    boll.move()
    if boll.distance(r_paddle) < 50 and boll.xcor() > 340:
        scoreboard.update()
        scoreboard.increace()
    if boll.distance(l_paddle) < 50 and boll.xcor() < -340:
        scoreboard_2.update()
        scoreboard_2.increace()
    if boll.ycor() > 280 or boll.ycor() < -290:
        boll.bounce()
    if boll.distance(r_paddle) < 50 and boll.xcor() > 340:
        boll.bounce_1()
    if boll.distance(l_paddle) < 50 and boll.xcor() < -340:
        boll.bounce_2()
    if boll.xcor() > 410 or boll.xcor() < -410:
        is_game_on = False
        scoreboard.game_over()

screen.exitonclick()