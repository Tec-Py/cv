
from turtle import Turtle

class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.score =0
        self.penup()
        self.goto(200, 265)
        self.color("white")
        self.hideturtle()
        self.update()

    def update(self):
        self.write(f"Score {self.score}", align="center", font=("Courier", 24, "normal"))

    def game_over(self):
        self.goto(0, 0)
        self.write("Game Over", align="center", font=("Courier", 35, "normal"))

    def increace(self):
        self.score+=1
        self.clear()
        self.update()
class Scoreboard_2(Turtle):

    def __init__(self):
        super().__init__()
        self.score =0
        self.penup()
        self.goto(-200, 265)
        self.color("white")
        self.hideturtle()
        self.update()

    def update(self):
        self.write(f"Score {self.score}", align="center", font=("Courier", 24, "normal"))

    def game_over(self):
        self.goto(0, 0)
        self.write("Game Over", align="center", font=("Courier", 35, "normal"))

    def increace(self):
        self.score+=1
        self.clear()
        self.update()