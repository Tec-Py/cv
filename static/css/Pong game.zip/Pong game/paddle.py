from turtle import Turtle

class Paddle(Turtle):
    def __init__(self, position):
        super().__init__()
        self.shape("square")
        self.shapesize(5, 1, 5)
        self.color("white")
        self.penup()
        self.goto(position)

    def up(self):
        y_cor = self.ycor() + 50
        self.goto(self.xcor(), y_cor)

    def down(self):
        y_cor = self.ycor() - 50
        self.goto(self.xcor(), y_cor)